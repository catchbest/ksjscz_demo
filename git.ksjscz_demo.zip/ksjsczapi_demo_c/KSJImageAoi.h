/*
 * KSJImageAoi.h
 *
 *  Created on: 2016-10-24
 *      Author: Mike
 */

#ifndef KSJIMAGEAOI_H_
#define KSJIMAGEAOI_H_

// ����AOI�����
int KSJIMAGE_ShowAoi(unsigned char *pData, int nWidth, int nHeight, int nBitCount, int nAoiX, int nAoiY, int nAoiW, int nAoiH);


#endif /* KSJIMAGEAOI_H_ */
