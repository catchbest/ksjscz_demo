All the following demo projects can build by eclipse in Windows PC or using arm-linux-gnueabihf in linux system

ksjsczapi_demo_capture: a demo project introduces how to capture a picture
ksjsczapi_demo_cpp    : a simple c++ demo project
ksjsczapi_demo_opencv : a demo project introduces how to using opencv in the project
ksjsczapi_demo_qimage : a demo project introduces how to convert the capture data to qimage and show
ksjsczapi_demo_qt     : the main demo project
ksjsczapi_demo_show   : a demo project introduces how to using image by pl
ksjsczapi_demo_tcp    : a demo project of tcp server
ksjsczapi_demo_zbar   : a demo project of zbar